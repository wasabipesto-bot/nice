
#include <cuda_runtime.h>
typedef unsigned int uint;
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;
typedef unsigned long long int uint64;
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
typedef signed long long int int64;

struct info_st {
    uint32 scalars_uint32[4];uint32 static_meta[26];
};


extern "C" __global__ void __launch_bounds__(256, 5)join_kernel (
    const uint32* __restrict__ buffer_0, const uint32* __restrict__ buffer_1, const uint32* __restrict__ buffer_2, const uint32* __restrict__ buffer_3, const uint32* __restrict__ buffer_4, const uint32* __restrict__ buffer_5, const uint32* __restrict__ buffer_6, const uint32* __restrict__ buffer_7, const uint32* __restrict__ buffer_8, uint32* buffer_9, uint32* buffer_10, uint32* buffer_11, uint32* buffer_12, const __grid_constant__ info_st info
) {
uint3 absoluteIdx = make_uint3(
    blockIdx.x * blockDim.x + threadIdx.x,
    blockIdx.y * blockDim.y + threadIdx.y,
    blockIdx.z * blockDim.z + threadIdx.z
);
uint32 idxGlobal = (
                absoluteIdx.z * gridDim.x * blockDim.x * gridDim.y * blockDim.y)
                + (absoluteIdx.y * gridDim.x * blockDim.x)
                + absoluteIdx.x;
uint32 warpSizeChecked = min(warpSize, blockDim.x * blockDim.y * blockDim.z);
extern __shared__ __align__(4) uint8 dynamic_shared_mem[];
// Shared array size: 256, 1024 bytes
uint32 *shared_memory_6 = reinterpret_cast<uint32*>(&dynamic_shared_mem[13352]);
// Shared array size: 256, 1024 bytes
uint32 *shared_memory_2 = reinterpret_cast<uint32*>(&dynamic_shared_mem[4]);
// Shared array size: 256, 1024 bytes
uint32 *shared_memory_5 = reinterpret_cast<uint32*>(&dynamic_shared_mem[2052]);
// Shared array size: 256, 1024 bytes
uint32 *shared_memory_7 = reinterpret_cast<uint32*>(&dynamic_shared_mem[3108]);
// Shared array size: 1024, 4096 bytes
uint32 *shared_memory_13 = reinterpret_cast<uint32*>(&dynamic_shared_mem[5156]);
// Shared array size: 256, 1024 bytes
uint32 *shared_memory_9 = reinterpret_cast<uint32*>(&dynamic_shared_mem[11304]);
// Shared array size: 256, 1024 bytes
uint32 *shared_memory_4 = reinterpret_cast<uint32*>(&dynamic_shared_mem[12328]);
// Shared array size: 1, 4 bytes
uint32 *shared_memory_14 = reinterpret_cast<uint32*>(&dynamic_shared_mem[0]);
// Shared array size: 8, 32 bytes
uint32 *shared_memory_10 = reinterpret_cast<uint32*>(&dynamic_shared_mem[3076]);
// Shared array size: 256, 1024 bytes
uint32 *shared_memory_8 = reinterpret_cast<uint32*>(&dynamic_shared_mem[4132]);
// Shared array size: 1, 4 bytes
uint32 *shared_memory_15 = reinterpret_cast<uint32*>(&dynamic_shared_mem[9252]);
// Shared array size: 512, 2048 bytes
uint32 *shared_memory_11 = reinterpret_cast<uint32*>(&dynamic_shared_mem[9256]);
// Shared array size: 1024, 4096 bytes
uint32 *shared_memory_12 = reinterpret_cast<uint32*>(&dynamic_shared_mem[14376]);
// Shared array size: 256, 1024 bytes
uint32 *shared_memory_3 = reinterpret_cast<uint32*>(&dynamic_shared_mem[1028]);
uint32 l_arr_436[2];

uint32 l_arr_437[2];

uint32 l_arr_438[2];

uint32 l_arr_439[2];

uint32 l_arr_440[2];

uint32 l_arr_441[2];

uint32 l_arr_442[2];

uint32 l_arr_443[2];

uint32 l_arr_557[8];

uint32 l_arr_562[2];

bool l_mut_785;
uint64 l_mut_460;
uint32 l_mut_0;
uint32 l_mut_1;
uint32 l_mut_16;
uint32 l_mut_21;
uint32 l_mut_54;
uint32 l_mut_55;
uint32 l_mut_59;
uint32 l_mut_67;
uint32 l_mut_70;
uint32 l_mut_71;
uint32 l_mut_477;
uint32 l_mut_496;
l_mut_0 = uint32(0);
l_mut_1 = uint32(0);
l_mut_16 = uint32(0);
const bool l_17 = threadIdx.x == uint32(0);
if (l_17) {
uint32* l_18 = &shared_memory_14[uint32(0)];
uint32 _tmp_0 = atomicExch(l_18, uint32(0));
}
const bool l_19 = threadIdx.x < uint32(8);
if (l_19) {
uint32* l_20 = &shared_memory_10[threadIdx.x];
uint32 _tmp_1 = atomicExch(l_20, uint32(0));
}
__syncthreads();

l_mut_21 = blockIdx.x;
while (true) {
const bool l_22 = l_mut_21 < info.scalars_uint32[0];
const bool l_23 = !l_22;
if (l_23) {
break;}
const uint32 l_24 = uint32(4) * l_mut_21;
const uint32 l_25 = buffer_6[l_24];
const uint32 l_26 = uint32(4) * l_mut_21;
const uint32 l_27 = l_26 + uint32(1);
const uint32 l_28 = buffer_6[l_27];
const uint32 l_29 = uint32(4) * l_mut_21;
const uint32 l_30 = l_29 + uint32(2);
const uint32 l_31 = buffer_6[l_30];
const uint32 l_32 = uint32(4) * l_mut_21;
const uint32 l_33 = l_32 + uint32(3);
const uint32 l_34 = buffer_6[l_33];
const uint32 l_35 = l_28 / uint32(59);
const uint32 l_36 = l_35 * uint32(59);
const uint32 l_37 = l_28 - l_36;
const uint32 l_38 = buffer_3[l_37];
const uint32 l_39 = l_37 + uint32(1);
const uint32 l_40 = buffer_3[l_39];
const uint32 l_41 = l_40 - l_38;
const uint32 l_42 = l_25 * uint32(60);
const uint32 l_43 = l_42 + l_35;
const uint32 l_44 = l_43 * uint32(59);
const uint32 l_45 = l_44 + l_37;
const uint32 l_46 = buffer_5[l_45];
const uint32 l_47 = l_25 * uint32(60);
const uint32 l_48 = l_47 * info.scalars_uint32[1];
const uint32 l_49 = uint32(60) * l_38;
const uint32 l_50 = l_48 + l_49;
const uint32 l_51 = l_35 * l_41;
const uint32 l_52 = l_50 + l_51;
const uint32 l_53 = l_25 * info.scalars_uint32[1];
l_mut_54 = uint32(0);
l_mut_55 = l_31;
while (true) {
const bool l_56 = l_mut_55 < l_34;
const bool l_57 = !l_56;
if (l_57) {
break;}
const uint32 l_58 = l_34 - l_mut_55;
l_mut_59 = l_58;
const bool l_60 = l_mut_59 > uint32(256);
if (l_60) {
l_mut_59 = uint32(256);
}
const bool l_61 = threadIdx.x < l_mut_59;
if (l_61) {
const uint32 l_62 = l_mut_55 + threadIdx.x;
const uint32 l_63 = buffer_7[l_62];
const uint32 l_64 = uint32(8) * l_63;
const uint32 l_65 = l_64 + uint32(2);
const uint32 l_66 = buffer_8[l_65];
l_mut_67 = l_66;
const uint32 l_68 = l_64 + uint32(3);
const uint32 l_69 = buffer_8[l_68];
l_mut_70 = l_69;
l_mut_71 = l_mut_67;
const uint32 l_72 = uint32(__brev(l_mut_70));
l_mut_67 = l_72;
const uint32 l_73 = uint32(__brev(l_mut_71));
l_mut_70 = l_73;
shared_memory_2[threadIdx.x] = l_mut_67;
shared_memory_3[threadIdx.x] = l_mut_70;
const uint32 l_74 = l_64 + uint32(4);
const uint32 l_75 = buffer_8[l_74];
const uint32 l_76 = l_64 + uint32(5);
const uint32 l_77 = buffer_8[l_76];
shared_memory_4[threadIdx.x] = l_75;
shared_memory_5[threadIdx.x] = l_77;
const bool l_78 = l_75 != uint32(0);
const bool l_79 = l_77 != info.scalars_uint32[3];
const bool l_80 = l_78 || l_79;
if (l_80) {
const uint32 l_81 = threadIdx.x % uint32(32);
const uint32 l_82 = uint32(1) << l_81;
const uint32 l_83 = threadIdx.x / uint32(32);
uint32* l_84 = &shared_memory_10[l_83];
const uint32 l_85 = atomicOr(l_84, l_82);
}
shared_memory_6[threadIdx.x] = l_63;
const uint32 l_86 = l_64 + uint32(6);
const uint32 l_87 = buffer_8[l_86];
const uint32 l_88 = l_87 / uint32(216000);
const uint32 l_89 = l_64 + uint32(7);
const uint32 l_90 = buffer_8[l_89];
const uint32 l_91 = l_88 * uint32(1193046);
const uint32 l_92 = l_88 * uint32(1696);
const uint32 l_93 = l_92 + uint32(3599);
const uint32 l_94 = l_93 / uint32(3600);
const uint32 l_95 = l_91 + l_94;
shared_memory_7[threadIdx.x] = l_95;
const bool l_96 = l_90 != uint32(0);
const uint32 l_97 = (l_96) ? l_mut_67 : uint32(0);
shared_memory_8[threadIdx.x] = l_97;
const bool l_98 = l_90 != uint32(0);
const uint32 l_99 = (l_98) ? l_mut_70 : uint32(0);
shared_memory_9[threadIdx.x] = l_99;
}
__syncthreads();

const bool l_100 = l_mut_59 >= uint32(192);
if (l_100) {
const uint32 l_101 = threadIdx.x / uint32(32);
const uint32 l_102 = threadIdx.x % uint32(32);
const uint32 l_103 = l_101 * uint32(32);
l_mut_71 = uint32(0);
l_mut_70 = uint32(0);
const bool l_104 = l_103 < l_mut_59;
if (l_104) {
const uint32 l_105 = l_103 + uint32(0);
const uint32 l_106 = shared_memory_2[l_105];
const uint32 l_107 = l_103 + uint32(0);
const uint32 l_108 = shared_memory_3[l_107];
const uint32 l_109 = l_106 >> l_102;
const uint32 l_110 = l_109 & uint32(1);
const uint32 l_111 = l_110 << uint32(0);
l_mut_71 = l_mut_71 | l_111;
const uint32 l_112 = l_108 >> l_102;
const uint32 l_113 = l_112 & uint32(1);
const uint32 l_114 = l_113 << uint32(0);
l_mut_70 = l_mut_70 | l_114;
const uint32 l_115 = l_103 + uint32(1);
const uint32 l_116 = shared_memory_2[l_115];
const uint32 l_117 = l_103 + uint32(1);
const uint32 l_118 = shared_memory_3[l_117];
const uint32 l_119 = l_116 >> l_102;
const uint32 l_120 = l_119 & uint32(1);
const uint32 l_121 = l_120 << uint32(1);
l_mut_71 = l_mut_71 | l_121;
const uint32 l_122 = l_118 >> l_102;
const uint32 l_123 = l_122 & uint32(1);
const uint32 l_124 = l_123 << uint32(1);
l_mut_70 = l_mut_70 | l_124;
const uint32 l_125 = l_103 + uint32(2);
const uint32 l_126 = shared_memory_2[l_125];
const uint32 l_127 = l_103 + uint32(2);
const uint32 l_128 = shared_memory_3[l_127];
const uint32 l_129 = l_126 >> l_102;
const uint32 l_130 = l_129 & uint32(1);
const uint32 l_131 = l_130 << uint32(2);
l_mut_71 = l_mut_71 | l_131;
const uint32 l_132 = l_128 >> l_102;
const uint32 l_133 = l_132 & uint32(1);
const uint32 l_134 = l_133 << uint32(2);
l_mut_70 = l_mut_70 | l_134;
const uint32 l_135 = l_103 + uint32(3);
const uint32 l_136 = shared_memory_2[l_135];
const uint32 l_137 = l_103 + uint32(3);
const uint32 l_138 = shared_memory_3[l_137];
const uint32 l_139 = l_136 >> l_102;
const uint32 l_140 = l_139 & uint32(1);
const uint32 l_141 = l_140 << uint32(3);
l_mut_71 = l_mut_71 | l_141;
const uint32 l_142 = l_138 >> l_102;
const uint32 l_143 = l_142 & uint32(1);
const uint32 l_144 = l_143 << uint32(3);
l_mut_70 = l_mut_70 | l_144;
const uint32 l_145 = l_103 + uint32(4);
const uint32 l_146 = shared_memory_2[l_145];
const uint32 l_147 = l_103 + uint32(4);
const uint32 l_148 = shared_memory_3[l_147];
const uint32 l_149 = l_146 >> l_102;
const uint32 l_150 = l_149 & uint32(1);
const uint32 l_151 = l_150 << uint32(4);
l_mut_71 = l_mut_71 | l_151;
const uint32 l_152 = l_148 >> l_102;
const uint32 l_153 = l_152 & uint32(1);
const uint32 l_154 = l_153 << uint32(4);
l_mut_70 = l_mut_70 | l_154;
const uint32 l_155 = l_103 + uint32(5);
const uint32 l_156 = shared_memory_2[l_155];
const uint32 l_157 = l_103 + uint32(5);
const uint32 l_158 = shared_memory_3[l_157];
const uint32 l_159 = l_156 >> l_102;
const uint32 l_160 = l_159 & uint32(1);
const uint32 l_161 = l_160 << uint32(5);
l_mut_71 = l_mut_71 | l_161;
const uint32 l_162 = l_158 >> l_102;
const uint32 l_163 = l_162 & uint32(1);
const uint32 l_164 = l_163 << uint32(5);
l_mut_70 = l_mut_70 | l_164;
const uint32 l_165 = l_103 + uint32(6);
const uint32 l_166 = shared_memory_2[l_165];
const uint32 l_167 = l_103 + uint32(6);
const uint32 l_168 = shared_memory_3[l_167];
const uint32 l_169 = l_166 >> l_102;
const uint32 l_170 = l_169 & uint32(1);
const uint32 l_171 = l_170 << uint32(6);
l_mut_71 = l_mut_71 | l_171;
const uint32 l_172 = l_168 >> l_102;
const uint32 l_173 = l_172 & uint32(1);
const uint32 l_174 = l_173 << uint32(6);
l_mut_70 = l_mut_70 | l_174;
const uint32 l_175 = l_103 + uint32(7);
const uint32 l_176 = shared_memory_2[l_175];
const uint32 l_177 = l_103 + uint32(7);
const uint32 l_178 = shared_memory_3[l_177];
const uint32 l_179 = l_176 >> l_102;
const uint32 l_180 = l_179 & uint32(1);
const uint32 l_181 = l_180 << uint32(7);
l_mut_71 = l_mut_71 | l_181;
const uint32 l_182 = l_178 >> l_102;
const uint32 l_183 = l_182 & uint32(1);
const uint32 l_184 = l_183 << uint32(7);
l_mut_70 = l_mut_70 | l_184;
const uint32 l_185 = l_103 + uint32(8);
const uint32 l_186 = shared_memory_2[l_185];
const uint32 l_187 = l_103 + uint32(8);
const uint32 l_188 = shared_memory_3[l_187];
const uint32 l_189 = l_186 >> l_102;
const uint32 l_190 = l_189 & uint32(1);
const uint32 l_191 = l_190 << uint32(8);
l_mut_71 = l_mut_71 | l_191;
const uint32 l_192 = l_188 >> l_102;
const uint32 l_193 = l_192 & uint32(1);
const uint32 l_194 = l_193 << uint32(8);
l_mut_70 = l_mut_70 | l_194;
const uint32 l_195 = l_103 + uint32(9);
const uint32 l_196 = shared_memory_2[l_195];
const uint32 l_197 = l_103 + uint32(9);
const uint32 l_198 = shared_memory_3[l_197];
const uint32 l_199 = l_196 >> l_102;
const uint32 l_200 = l_199 & uint32(1);
const uint32 l_201 = l_200 << uint32(9);
l_mut_71 = l_mut_71 | l_201;
const uint32 l_202 = l_198 >> l_102;
const uint32 l_203 = l_202 & uint32(1);
const uint32 l_204 = l_203 << uint32(9);
l_mut_70 = l_mut_70 | l_204;
const uint32 l_205 = l_103 + uint32(10);
const uint32 l_206 = shared_memory_2[l_205];
const uint32 l_207 = l_103 + uint32(10);
const uint32 l_208 = shared_memory_3[l_207];
const uint32 l_209 = l_206 >> l_102;
const uint32 l_210 = l_209 & uint32(1);
const uint32 l_211 = l_210 << uint32(10);
l_mut_71 = l_mut_71 | l_211;
const uint32 l_212 = l_208 >> l_102;
const uint32 l_213 = l_212 & uint32(1);
const uint32 l_214 = l_213 << uint32(10);
l_mut_70 = l_mut_70 | l_214;
const uint32 l_215 = l_103 + uint32(11);
const uint32 l_216 = shared_memory_2[l_215];
const uint32 l_217 = l_103 + uint32(11);
const uint32 l_218 = shared_memory_3[l_217];
const uint32 l_219 = l_216 >> l_102;
const uint32 l_220 = l_219 & uint32(1);
const uint32 l_221 = l_220 << uint32(11);
l_mut_71 = l_mut_71 | l_221;
const uint32 l_222 = l_218 >> l_102;
const uint32 l_223 = l_222 & uint32(1);
const uint32 l_224 = l_223 << uint32(11);
l_mut_70 = l_mut_70 | l_224;
const uint32 l_225 = l_103 + uint32(12);
const uint32 l_226 = shared_memory_2[l_225];
const uint32 l_227 = l_103 + uint32(12);
const uint32 l_228 = shared_memory_3[l_227];
const uint32 l_229 = l_226 >> l_102;
const uint32 l_230 = l_229 & uint32(1);
const uint32 l_231 = l_230 << uint32(12);
l_mut_71 = l_mut_71 | l_231;
const uint32 l_232 = l_228 >> l_102;
const uint32 l_233 = l_232 & uint32(1);
const uint32 l_234 = l_233 << uint32(12);
l_mut_70 = l_mut_70 | l_234;
const uint32 l_235 = l_103 + uint32(13);
const uint32 l_236 = shared_memory_2[l_235];
const uint32 l_237 = l_103 + uint32(13);
const uint32 l_238 = shared_memory_3[l_237];
const uint32 l_239 = l_236 >> l_102;
const uint32 l_240 = l_239 & uint32(1);
const uint32 l_241 = l_240 << uint32(13);
l_mut_71 = l_mut_71 | l_241;
const uint32 l_242 = l_238 >> l_102;
const uint32 l_243 = l_242 & uint32(1);
const uint32 l_244 = l_243 << uint32(13);
l_mut_70 = l_mut_70 | l_244;
const uint32 l_245 = l_103 + uint32(14);
const uint32 l_246 = shared_memory_2[l_245];
const uint32 l_247 = l_103 + uint32(14);
const uint32 l_248 = shared_memory_3[l_247];
const uint32 l_249 = l_246 >> l_102;
const uint32 l_250 = l_249 & uint32(1);
const uint32 l_251 = l_250 << uint32(14);
l_mut_71 = l_mut_71 | l_251;
const uint32 l_252 = l_248 >> l_102;
const uint32 l_253 = l_252 & uint32(1);
const uint32 l_254 = l_253 << uint32(14);
l_mut_70 = l_mut_70 | l_254;
const uint32 l_255 = l_103 + uint32(15);
const uint32 l_256 = shared_memory_2[l_255];
const uint32 l_257 = l_103 + uint32(15);
const uint32 l_258 = shared_memory_3[l_257];
const uint32 l_259 = l_256 >> l_102;
const uint32 l_260 = l_259 & uint32(1);
const uint32 l_261 = l_260 << uint32(15);
l_mut_71 = l_mut_71 | l_261;
const uint32 l_262 = l_258 >> l_102;
const uint32 l_263 = l_262 & uint32(1);
const uint32 l_264 = l_263 << uint32(15);
l_mut_70 = l_mut_70 | l_264;
const uint32 l_265 = l_103 + uint32(16);
const uint32 l_266 = shared_memory_2[l_265];
const uint32 l_267 = l_103 + uint32(16);
const uint32 l_268 = shared_memory_3[l_267];
const uint32 l_269 = l_266 >> l_102;
const uint32 l_270 = l_269 & uint32(1);
const uint32 l_271 = l_270 << uint32(16);
l_mut_71 = l_mut_71 | l_271;
const uint32 l_272 = l_268 >> l_102;
const uint32 l_273 = l_272 & uint32(1);
const uint32 l_274 = l_273 << uint32(16);
l_mut_70 = l_mut_70 | l_274;
const uint32 l_275 = l_103 + uint32(17);
const uint32 l_276 = shared_memory_2[l_275];
const uint32 l_277 = l_103 + uint32(17);
const uint32 l_278 = shared_memory_3[l_277];
const uint32 l_279 = l_276 >> l_102;
const uint32 l_280 = l_279 & uint32(1);
const uint32 l_281 = l_280 << uint32(17);
l_mut_71 = l_mut_71 | l_281;
const uint32 l_282 = l_278 >> l_102;
const uint32 l_283 = l_282 & uint32(1);
const uint32 l_284 = l_283 << uint32(17);
l_mut_70 = l_mut_70 | l_284;
const uint32 l_285 = l_103 + uint32(18);
const uint32 l_286 = shared_memory_2[l_285];
const uint32 l_287 = l_103 + uint32(18);
const uint32 l_288 = shared_memory_3[l_287];
const uint32 l_289 = l_286 >> l_102;
const uint32 l_290 = l_289 & uint32(1);
const uint32 l_291 = l_290 << uint32(18);
l_mut_71 = l_mut_71 | l_291;
const uint32 l_292 = l_288 >> l_102;
const uint32 l_293 = l_292 & uint32(1);
const uint32 l_294 = l_293 << uint32(18);
l_mut_70 = l_mut_70 | l_294;
const uint32 l_295 = l_103 + uint32(19);
const uint32 l_296 = shared_memory_2[l_295];
const uint32 l_297 = l_103 + uint32(19);
const uint32 l_298 = shared_memory_3[l_297];
const uint32 l_299 = l_296 >> l_102;
const uint32 l_300 = l_299 & uint32(1);
const uint32 l_301 = l_300 << uint32(19);
l_mut_71 = l_mut_71 | l_301;
const uint32 l_302 = l_298 >> l_102;
const uint32 l_303 = l_302 & uint32(1);
const uint32 l_304 = l_303 << uint32(19);
l_mut_70 = l_mut_70 | l_304;
const uint32 l_305 = l_103 + uint32(20);
const uint32 l_306 = shared_memory_2[l_305];
const uint32 l_307 = l_103 + uint32(20);
const uint32 l_308 = shared_memory_3[l_307];
const uint32 l_309 = l_306 >> l_102;
const uint32 l_310 = l_309 & uint32(1);
const uint32 l_311 = l_310 << uint32(20);
l_mut_71 = l_mut_71 | l_311;
const uint32 l_312 = l_308 >> l_102;
const uint32 l_313 = l_312 & uint32(1);
const uint32 l_314 = l_313 << uint32(20);
l_mut_70 = l_mut_70 | l_314;
const uint32 l_315 = l_103 + uint32(21);
const uint32 l_316 = shared_memory_2[l_315];
const uint32 l_317 = l_103 + uint32(21);
const uint32 l_318 = shared_memory_3[l_317];
const uint32 l_319 = l_316 >> l_102;
const uint32 l_320 = l_319 & uint32(1);
const uint32 l_321 = l_320 << uint32(21);
l_mut_71 = l_mut_71 | l_321;
const uint32 l_322 = l_318 >> l_102;
const uint32 l_323 = l_322 & uint32(1);
const uint32 l_324 = l_323 << uint32(21);
l_mut_70 = l_mut_70 | l_324;
const uint32 l_325 = l_103 + uint32(22);
const uint32 l_326 = shared_memory_2[l_325];
const uint32 l_327 = l_103 + uint32(22);
const uint32 l_328 = shared_memory_3[l_327];
const uint32 l_329 = l_326 >> l_102;
const uint32 l_330 = l_329 & uint32(1);
const uint32 l_331 = l_330 << uint32(22);
l_mut_71 = l_mut_71 | l_331;
const uint32 l_332 = l_328 >> l_102;
const uint32 l_333 = l_332 & uint32(1);
const uint32 l_334 = l_333 << uint32(22);
l_mut_70 = l_mut_70 | l_334;
const uint32 l_335 = l_103 + uint32(23);
const uint32 l_336 = shared_memory_2[l_335];
const uint32 l_337 = l_103 + uint32(23);
const uint32 l_338 = shared_memory_3[l_337];
const uint32 l_339 = l_336 >> l_102;
const uint32 l_340 = l_339 & uint32(1);
const uint32 l_341 = l_340 << uint32(23);
l_mut_71 = l_mut_71 | l_341;
const uint32 l_342 = l_338 >> l_102;
const uint32 l_343 = l_342 & uint32(1);
const uint32 l_344 = l_343 << uint32(23);
l_mut_70 = l_mut_70 | l_344;
const uint32 l_345 = l_103 + uint32(24);
const uint32 l_346 = shared_memory_2[l_345];
const uint32 l_347 = l_103 + uint32(24);
const uint32 l_348 = shared_memory_3[l_347];
const uint32 l_349 = l_346 >> l_102;
const uint32 l_350 = l_349 & uint32(1);
const uint32 l_351 = l_350 << uint32(24);
l_mut_71 = l_mut_71 | l_351;
const uint32 l_352 = l_348 >> l_102;
const uint32 l_353 = l_352 & uint32(1);
const uint32 l_354 = l_353 << uint32(24);
l_mut_70 = l_mut_70 | l_354;
const uint32 l_355 = l_103 + uint32(25);
const uint32 l_356 = shared_memory_2[l_355];
const uint32 l_357 = l_103 + uint32(25);
const uint32 l_358 = shared_memory_3[l_357];
const uint32 l_359 = l_356 >> l_102;
const uint32 l_360 = l_359 & uint32(1);
const uint32 l_361 = l_360 << uint32(25);
l_mut_71 = l_mut_71 | l_361;
const uint32 l_362 = l_358 >> l_102;
const uint32 l_363 = l_362 & uint32(1);
const uint32 l_364 = l_363 << uint32(25);
l_mut_70 = l_mut_70 | l_364;
const uint32 l_365 = l_103 + uint32(26);
const uint32 l_366 = shared_memory_2[l_365];
const uint32 l_367 = l_103 + uint32(26);
const uint32 l_368 = shared_memory_3[l_367];
const uint32 l_369 = l_366 >> l_102;
const uint32 l_370 = l_369 & uint32(1);
const uint32 l_371 = l_370 << uint32(26);
l_mut_71 = l_mut_71 | l_371;
const uint32 l_372 = l_368 >> l_102;
const uint32 l_373 = l_372 & uint32(1);
const uint32 l_374 = l_373 << uint32(26);
l_mut_70 = l_mut_70 | l_374;
const uint32 l_375 = l_103 + uint32(27);
const uint32 l_376 = shared_memory_2[l_375];
const uint32 l_377 = l_103 + uint32(27);
const uint32 l_378 = shared_memory_3[l_377];
const uint32 l_379 = l_376 >> l_102;
const uint32 l_380 = l_379 & uint32(1);
const uint32 l_381 = l_380 << uint32(27);
l_mut_71 = l_mut_71 | l_381;
const uint32 l_382 = l_378 >> l_102;
const uint32 l_383 = l_382 & uint32(1);
const uint32 l_384 = l_383 << uint32(27);
l_mut_70 = l_mut_70 | l_384;
const uint32 l_385 = l_103 + uint32(28);
const uint32 l_386 = shared_memory_2[l_385];
const uint32 l_387 = l_103 + uint32(28);
const uint32 l_388 = shared_memory_3[l_387];
const uint32 l_389 = l_386 >> l_102;
const uint32 l_390 = l_389 & uint32(1);
const uint32 l_391 = l_390 << uint32(28);
l_mut_71 = l_mut_71 | l_391;
const uint32 l_392 = l_388 >> l_102;
const uint32 l_393 = l_392 & uint32(1);
const uint32 l_394 = l_393 << uint32(28);
l_mut_70 = l_mut_70 | l_394;
const uint32 l_395 = l_103 + uint32(29);
const uint32 l_396 = shared_memory_2[l_395];
const uint32 l_397 = l_103 + uint32(29);
const uint32 l_398 = shared_memory_3[l_397];
const uint32 l_399 = l_396 >> l_102;
const uint32 l_400 = l_399 & uint32(1);
const uint32 l_401 = l_400 << uint32(29);
l_mut_71 = l_mut_71 | l_401;
const uint32 l_402 = l_398 >> l_102;
const uint32 l_403 = l_402 & uint32(1);
const uint32 l_404 = l_403 << uint32(29);
l_mut_70 = l_mut_70 | l_404;
const uint32 l_405 = l_103 + uint32(30);
const uint32 l_406 = shared_memory_2[l_405];
const uint32 l_407 = l_103 + uint32(30);
const uint32 l_408 = shared_memory_3[l_407];
const uint32 l_409 = l_406 >> l_102;
const uint32 l_410 = l_409 & uint32(1);
const uint32 l_411 = l_410 << uint32(30);
l_mut_71 = l_mut_71 | l_411;
const uint32 l_412 = l_408 >> l_102;
const uint32 l_413 = l_412 & uint32(1);
const uint32 l_414 = l_413 << uint32(30);
l_mut_70 = l_mut_70 | l_414;
const uint32 l_415 = l_103 + uint32(31);
const uint32 l_416 = shared_memory_2[l_415];
const uint32 l_417 = l_103 + uint32(31);
const uint32 l_418 = shared_memory_3[l_417];
const uint32 l_419 = l_416 >> l_102;
const uint32 l_420 = l_419 & uint32(1);
const uint32 l_421 = l_420 << uint32(31);
l_mut_71 = l_mut_71 | l_421;
const uint32 l_422 = l_418 >> l_102;
const uint32 l_423 = l_422 & uint32(1);
const uint32 l_424 = l_423 << uint32(31);
l_mut_70 = l_mut_70 | l_424;
const uint32 l_425 = l_mut_59 - l_103;
const bool l_426 = l_425 < uint32(32);
if (l_426) {
const uint32 l_427 = uint32(1) << l_425;
const uint32 l_428 = l_427 - uint32(1);
l_mut_71 = l_mut_71 & l_428;
l_mut_70 = l_mut_70 & l_428;
}
}
const uint32 l_429 = l_101 * uint32(64);
const uint32 l_430 = l_429 + l_102;
shared_memory_11[l_430] = l_mut_71;
const uint32 l_431 = l_101 * uint32(64);
const uint32 l_432 = l_431 + uint32(32);
const uint32 l_433 = l_432 + l_102;
shared_memory_11[l_433] = l_mut_70;
}
__syncthreads();

l_mut_71 = uint32(0);
while (true) {
const bool l_434 = l_mut_71 < l_46;
const bool l_435 = !l_434;
if (l_435) {
break;}
const uint32 l_444 = l_mut_71 + threadIdx.x;
const uint32 l_445 = l_444 + uint32(0);
l_arr_436[uint32(0)] = uint32(4294967295);
l_arr_437[uint32(0)] = uint32(4294967295);
l_arr_438[uint32(0)] = uint32(0);
l_arr_439[uint32(0)] = uint32(0);
l_arr_440[uint32(0)] = uint32(0);
l_arr_441[uint32(0)] = uint32(0);
l_arr_442[uint32(0)] = uint32(0);
l_arr_443[uint32(0)] = uint32(0);
const bool l_446 = l_445 < l_46;
if (l_446) {
l_arr_439[uint32(0)] = uint32(4294967295);
const uint32 l_447 = l_52 + l_445;
const uint32 l_448 = buffer_4[l_447];
const uint32 l_449 = l_53 + l_448;
const uint32 l_450 = buffer_2[l_448];
const uint32 l_451 = uint32(2) * l_449;
const uint32 l_452 = l_451 + uint32(1);
const uint32 l_453 = buffer_0[l_452];
const uint64 l_454 = uint64(l_453);
const uint64 l_455 = l_454 << uint64(32);
const uint32 l_456 = uint32(2) * l_449;
const uint32 l_457 = buffer_0[l_456];
const uint64 l_458 = uint64(l_457);
const uint64 l_459 = l_455 | l_458;
l_mut_460 = l_459;
const uint32 l_461 = uint32(2) * l_449;
const uint32 l_462 = buffer_1[l_461];
const uint32 l_463 = uint32(2) * l_449;
const uint32 l_464 = l_463 + uint32(1);
const uint32 l_465 = buffer_1[l_464];
l_mut_70 = l_450;
const uint32 l_466 = l_462 >> uint32(18);
const uint32 l_467 = l_465 >> uint32(18);
const uint32 l_468 = l_467 << uint32(14);
const uint32 l_469 = l_466 | l_468;
const uint32 l_470 = l_462 & uint32(262143);
const uint32 l_471 = uint32(2) * l_mut_70;
const uint32 l_472 = l_35 * l_471;
const uint32 l_473 = l_470 + l_472;
l_mut_67 = l_473;
const uint32 l_474 = l_465 & uint32(262143);
const uint32 l_475 = l_35 * l_469;
const uint32 l_476 = l_474 + l_475;
l_mut_477 = l_476;
l_mut_67 = l_mut_67 % uint32(216000);
l_mut_477 = l_mut_477 % uint32(216000);
const uint32 l_478 = l_mut_67 % uint32(60);
const uint32 l_479 = l_mut_477 % uint32(60);
const uint64 l_480 = uint64(l_478);
const uint64 l_481 = uint64(1) << l_480;
const uint64 l_482 = uint64(l_479);
const uint64 l_483 = uint64(1) << l_482;
const uint64 l_484 = l_481 | l_483;
l_mut_460 = l_mut_460 | l_484;
const uint32 l_485 = l_mut_67 / uint32(60);
const uint32 l_486 = l_485 * uint32(1193047);
l_arr_440[uint32(0)] = l_486;
const uint32 l_487 = l_mut_477 / uint32(60);
const uint32 l_488 = l_487 * uint32(1193047);
l_arr_442[uint32(0)] = l_488;
const uint32 l_489 = l_mut_70 % uint32(3600);
l_mut_70 = l_489;
const uint32 l_490 = l_mut_70 * l_mut_70;
const uint32 l_491 = l_490 % uint32(3600);
const uint32 l_492 = uint32(3) * l_491;
const uint32 l_493 = l_492 % uint32(3600);
const uint32 l_494 = uint32(2) * l_mut_70;
const uint32 l_495 = l_494 % uint32(3600);
l_mut_496 = l_495;
l_arr_441[uint32(0)] = l_mut_496;
l_arr_443[uint32(0)] = l_493;
const uint64 l_497 = l_mut_460 >> uint64(32);
const uint32 l_498 = uint32(l_497);
const uint32 l_499 = uint32(__brev(l_498));
l_arr_436[uint32(0)] = l_499;
const uint32 l_500 = uint32(l_mut_460);
const uint32 l_501 = uint32(__brev(l_500));
l_arr_437[uint32(0)] = l_501;
l_arr_438[uint32(0)] = l_450;
}
const uint32 l_502 = l_mut_71 + threadIdx.x;
const uint32 l_503 = l_502 + uint32(256);
l_arr_436[uint32(1)] = uint32(4294967295);
l_arr_437[uint32(1)] = uint32(4294967295);
l_arr_438[uint32(1)] = uint32(0);
l_arr_439[uint32(1)] = uint32(0);
l_arr_440[uint32(1)] = uint32(0);
l_arr_441[uint32(1)] = uint32(0);
l_arr_442[uint32(1)] = uint32(0);
l_arr_443[uint32(1)] = uint32(0);
const bool l_504 = l_503 < l_46;
if (l_504) {
l_arr_439[uint32(1)] = uint32(4294967295);
const uint32 l_505 = l_52 + l_503;
const uint32 l_506 = buffer_4[l_505];
const uint32 l_507 = l_53 + l_506;
const uint32 l_508 = buffer_2[l_506];
const uint32 l_509 = uint32(2) * l_507;
const uint32 l_510 = l_509 + uint32(1);
const uint32 l_511 = buffer_0[l_510];
const uint64 l_512 = uint64(l_511);
const uint64 l_513 = l_512 << uint64(32);
const uint32 l_514 = uint32(2) * l_507;
const uint32 l_515 = buffer_0[l_514];
const uint64 l_516 = uint64(l_515);
const uint64 l_517 = l_513 | l_516;
l_mut_460 = l_517;
const uint32 l_518 = uint32(2) * l_507;
const uint32 l_519 = buffer_1[l_518];
const uint32 l_520 = uint32(2) * l_507;
const uint32 l_521 = l_520 + uint32(1);
const uint32 l_522 = buffer_1[l_521];
l_mut_496 = l_508;
const uint32 l_523 = l_519 >> uint32(18);
const uint32 l_524 = l_522 >> uint32(18);
const uint32 l_525 = l_524 << uint32(14);
const uint32 l_526 = l_523 | l_525;
const uint32 l_527 = l_519 & uint32(262143);
const uint32 l_528 = uint32(2) * l_mut_496;
const uint32 l_529 = l_35 * l_528;
const uint32 l_530 = l_527 + l_529;
l_mut_477 = l_530;
const uint32 l_531 = l_522 & uint32(262143);
const uint32 l_532 = l_35 * l_526;
const uint32 l_533 = l_531 + l_532;
l_mut_70 = l_533;
l_mut_477 = l_mut_477 % uint32(216000);
l_mut_70 = l_mut_70 % uint32(216000);
const uint32 l_534 = l_mut_477 % uint32(60);
const uint32 l_535 = l_mut_70 % uint32(60);
const uint64 l_536 = uint64(l_534);
const uint64 l_537 = uint64(1) << l_536;
const uint64 l_538 = uint64(l_535);
const uint64 l_539 = uint64(1) << l_538;
const uint64 l_540 = l_537 | l_539;
l_mut_460 = l_mut_460 | l_540;
const uint32 l_541 = l_mut_477 / uint32(60);
const uint32 l_542 = l_541 * uint32(1193047);
l_arr_440[uint32(1)] = l_542;
const uint32 l_543 = l_mut_70 / uint32(60);
const uint32 l_544 = l_543 * uint32(1193047);
l_arr_442[uint32(1)] = l_544;
const uint32 l_545 = l_mut_496 % uint32(3600);
l_mut_496 = l_545;
const uint32 l_546 = l_mut_496 * l_mut_496;
const uint32 l_547 = l_546 % uint32(3600);
const uint32 l_548 = uint32(3) * l_547;
const uint32 l_549 = l_548 % uint32(3600);
const uint32 l_550 = uint32(2) * l_mut_496;
const uint32 l_551 = l_550 % uint32(3600);
l_mut_67 = l_551;
l_arr_441[uint32(1)] = l_mut_67;
l_arr_443[uint32(1)] = l_549;
const uint64 l_552 = l_mut_460 >> uint64(32);
const uint32 l_553 = uint32(l_552);
const uint32 l_554 = uint32(__brev(l_553));
l_arr_436[uint32(1)] = l_554;
const uint32 l_555 = uint32(l_mut_460);
const uint32 l_556 = uint32(__brev(l_555));
l_arr_437[uint32(1)] = l_556;
l_arr_438[uint32(1)] = l_508;
}
l_mut_496 = uint32(0);
while (true) {
const bool l_558 = l_mut_496 < l_mut_59;
const bool l_559 = !l_558;
if (l_559) {
break;}
const uint32 l_560 = l_mut_496 + uint32(32);
l_mut_477 = l_560;
const bool l_561 = l_mut_477 > l_mut_59;
if (l_561) {
l_mut_477 = l_mut_59;
}
const bool l_563 = l_mut_59 >= uint32(192);
if (l_563) {
const uint32 l_564 = l_mut_496 / uint32(32);
const uint32 l_565 = l_564 % uint32(4);
const bool l_566 = l_565 == uint32(0);
if (l_566) {
l_arr_557[uint32(0)] = uint32(0);
l_arr_557[uint32(1)] = uint32(0);
l_arr_557[uint32(2)] = uint32(0);
l_arr_557[uint32(3)] = uint32(0);
l_arr_557[uint32(4)] = uint32(0);
l_arr_557[uint32(5)] = uint32(0);
l_arr_557[uint32(6)] = uint32(0);
l_arr_557[uint32(7)] = uint32(0);
const uint32 l_567 = l_564 * uint32(64);
const uint32 l_568 = l_arr_436[uint32(0)];
const uint32 l_569 = l_arr_439[uint32(0)];
const uint32 l_570 = l_568 & l_569;
l_mut_70 = l_570;
const uint32 l_571 = l_arr_437[uint32(0)];
const uint32 l_572 = l_arr_439[uint32(0)];
const uint32 l_573 = l_571 & l_572;
l_mut_67 = l_573;
while (true) {
const uint32 l_574 = l_mut_70 | l_mut_67;
const bool l_575 = l_574 != uint32(0);
const bool l_576 = !l_575;
if (l_576) {
break;}
const bool l_577 = l_mut_70 != uint32(0);
const uint32 l_578 = (l_577) ? l_mut_70 : l_mut_67;
const uint32 l_579 = uint32(__ffs(int32(l_578)));
const uint32 l_580 = l_579 - uint32(1);
const uint32 l_581 = (l_577) ? uint32(0) : uint32(32);
const uint32 l_582 = l_580 + l_581;
const uint32 l_583 = l_578 - uint32(1);
const uint32 l_584 = l_578 & l_583;
const uint32 l_585 = (l_577) ? l_584 : l_mut_70;
l_mut_70 = l_585;
const uint32 l_586 = (l_577) ? l_mut_67 : l_584;
l_mut_67 = l_586;
const uint32 l_587 = l_567 + l_582;
const uint32 l_588 = l_587 + uint32(0);
const uint32 l_589 = shared_memory_11[l_588];
const uint32 l_590 = l_arr_557[uint32(0)];
const uint32 l_591 = l_590 | l_589;
l_arr_557[uint32(0)] = l_591;
const uint32 l_592 = l_587 + uint32(64);
const uint32 l_593 = shared_memory_11[l_592];
const uint32 l_594 = l_arr_557[uint32(2)];
const uint32 l_595 = l_594 | l_593;
l_arr_557[uint32(2)] = l_595;
const uint32 l_596 = l_587 + uint32(128);
const uint32 l_597 = shared_memory_11[l_596];
const uint32 l_598 = l_arr_557[uint32(4)];
const uint32 l_599 = l_598 | l_597;
l_arr_557[uint32(4)] = l_599;
const uint32 l_600 = l_587 + uint32(192);
const uint32 l_601 = shared_memory_11[l_600];
const uint32 l_602 = l_arr_557[uint32(6)];
const uint32 l_603 = l_602 | l_601;
l_arr_557[uint32(6)] = l_603;
}
const uint32 l_604 = l_arr_436[uint32(1)];
const uint32 l_605 = l_arr_439[uint32(1)];
const uint32 l_606 = l_604 & l_605;
l_mut_70 = l_606;
const uint32 l_607 = l_arr_437[uint32(1)];
const uint32 l_608 = l_arr_439[uint32(1)];
const uint32 l_609 = l_607 & l_608;
l_mut_67 = l_609;
while (true) {
const uint32 l_610 = l_mut_70 | l_mut_67;
const bool l_611 = l_610 != uint32(0);
const bool l_612 = !l_611;
if (l_612) {
break;}
const bool l_613 = l_mut_70 != uint32(0);
const uint32 l_614 = (l_613) ? l_mut_70 : l_mut_67;
const uint32 l_615 = uint32(__ffs(int32(l_614)));
const uint32 l_616 = l_615 - uint32(1);
const uint32 l_617 = (l_613) ? uint32(0) : uint32(32);
const uint32 l_618 = l_616 + l_617;
const uint32 l_619 = l_614 - uint32(1);
const uint32 l_620 = l_614 & l_619;
const uint32 l_621 = (l_613) ? l_620 : l_mut_70;
l_mut_70 = l_621;
const uint32 l_622 = (l_613) ? l_mut_67 : l_620;
l_mut_67 = l_622;
const uint32 l_623 = l_567 + l_618;
const uint32 l_624 = l_623 + uint32(0);
const uint32 l_625 = shared_memory_11[l_624];
const uint32 l_626 = l_arr_557[uint32(1)];
const uint32 l_627 = l_626 | l_625;
l_arr_557[uint32(1)] = l_627;
const uint32 l_628 = l_623 + uint32(64);
const uint32 l_629 = shared_memory_11[l_628];
const uint32 l_630 = l_arr_557[uint32(3)];
const uint32 l_631 = l_630 | l_629;
l_arr_557[uint32(3)] = l_631;
const uint32 l_632 = l_623 + uint32(128);
const uint32 l_633 = shared_memory_11[l_632];
const uint32 l_634 = l_arr_557[uint32(5)];
const uint32 l_635 = l_634 | l_633;
l_arr_557[uint32(5)] = l_635;
const uint32 l_636 = l_623 + uint32(192);
const uint32 l_637 = shared_memory_11[l_636];
const uint32 l_638 = l_arr_557[uint32(7)];
const uint32 l_639 = l_638 | l_637;
l_arr_557[uint32(7)] = l_639;
}
}
const uint32 l_640 = l_mut_477 - l_mut_496;
const bool l_641 = l_640 >= uint32(32);
const uint32 l_642 = l_640 & uint32(31);
const uint32 l_643 = uint32(1) << l_642;
const uint32 l_644 = l_643 - uint32(1);
const uint32 l_645 = (l_641) ? uint32(4294967295) : l_644;
const uint32 l_646 = l_arr_557[uint32(0)];
const uint32 l_647 = l_646 ^ l_645;
const uint32 l_648 = l_647 & l_645;
l_arr_562[uint32(0)] = l_648;
const uint32 l_649 = l_arr_557[uint32(1)];
const uint32 l_650 = l_649 ^ l_645;
const uint32 l_651 = l_650 & l_645;
l_arr_562[uint32(1)] = l_651;
const uint32 l_652 = l_arr_557[uint32(2)];
l_arr_557[uint32(0)] = l_652;
const uint32 l_653 = l_arr_557[uint32(3)];
l_arr_557[uint32(1)] = l_653;
const uint32 l_654 = l_arr_557[uint32(4)];
l_arr_557[uint32(2)] = l_654;
const uint32 l_655 = l_arr_557[uint32(5)];
l_arr_557[uint32(3)] = l_655;
const uint32 l_656 = l_arr_557[uint32(6)];
l_arr_557[uint32(4)] = l_656;
const uint32 l_657 = l_arr_557[uint32(7)];
l_arr_557[uint32(5)] = l_657;
} else {
l_arr_562[uint32(0)] = uint32(0);
l_arr_562[uint32(1)] = uint32(0);
l_mut_70 = l_mut_496;
l_mut_67 = uint32(1);
while (true) {
const bool l_658 = l_mut_70 < l_mut_477;
const bool l_659 = !l_658;
if (l_659) {
break;}
const uint32 l_660 = shared_memory_2[l_mut_70];
const uint32 l_661 = shared_memory_3[l_mut_70];
const uint32 l_662 = l_arr_436[uint32(0)];
const uint32 l_663 = l_662 & l_660;
const uint32 l_664 = l_arr_437[uint32(0)];
const uint32 l_665 = l_664 & l_661;
const uint32 l_666 = l_663 | l_665;
const bool l_667 = l_666 == uint32(0);
const uint32 l_668 = (l_667) ? l_mut_67 : uint32(0);
const uint32 l_669 = l_arr_562[uint32(0)];
const uint32 l_670 = l_669 | l_668;
l_arr_562[uint32(0)] = l_670;
const uint32 l_671 = l_arr_436[uint32(1)];
const uint32 l_672 = l_671 & l_660;
const uint32 l_673 = l_arr_437[uint32(1)];
const uint32 l_674 = l_673 & l_661;
const uint32 l_675 = l_672 | l_674;
const bool l_676 = l_675 == uint32(0);
const uint32 l_677 = (l_676) ? l_mut_67 : uint32(0);
const uint32 l_678 = l_arr_562[uint32(1)];
const uint32 l_679 = l_678 | l_677;
l_arr_562[uint32(1)] = l_679;
l_mut_67 = l_mut_67 << uint32(1);
l_mut_70 = l_mut_70 + uint32(1);
}
}
const uint32 l_680 = l_mut_496 / uint32(32);
uint32* l_681 = &shared_memory_10[l_680];
const uint32 l_682 = atomicAdd(l_681, uint32(0));
const bool l_683 = l_682 != uint32(0);
if (l_683) {
const uint32 l_684 = l_arr_438[uint32(0)];
const uint32 l_685 = l_arr_562[uint32(0)];
const uint32 l_686 = l_arr_439[uint32(0)];
const uint32 l_687 = l_685 & l_686;
const uint32 l_688 = l_687 & l_682;
l_mut_70 = l_688;
while (true) {
const bool l_689 = l_mut_70 != uint32(0);
const bool l_690 = !l_689;
if (l_690) {
break;}
const uint32 l_691 = uint32((l_mut_70 == 0 ? 32 : __ffs(l_mut_70) - 1));
const uint32 l_692 = l_mut_70 - uint32(1);
l_mut_70 = l_mut_70 & l_692;
const uint32 l_693 = l_mut_496 + l_691;
const uint32 l_694 = shared_memory_4[l_693];
const bool l_695 = l_684 < l_694;
const uint32 l_696 = l_mut_496 + l_691;
const uint32 l_697 = shared_memory_5[l_696];
const bool l_698 = l_684 >= l_697;
const bool l_699 = l_695 || l_698;
if (l_699) {
const uint32 l_700 = uint32(1) << l_691;
const uint32 l_701 = l_arr_562[uint32(0)];
const uint32 l_702 = l_701 ^ l_700;
l_arr_562[uint32(0)] = l_702;
}
}
const uint32 l_703 = l_arr_438[uint32(1)];
const uint32 l_704 = l_arr_562[uint32(1)];
const uint32 l_705 = l_arr_439[uint32(1)];
const uint32 l_706 = l_704 & l_705;
const uint32 l_707 = l_706 & l_682;
l_mut_70 = l_707;
while (true) {
const bool l_708 = l_mut_70 != uint32(0);
const bool l_709 = !l_708;
if (l_709) {
break;}
const uint32 l_710 = uint32((l_mut_70 == 0 ? 32 : __ffs(l_mut_70) - 1));
const uint32 l_711 = l_mut_70 - uint32(1);
l_mut_70 = l_mut_70 & l_711;
const uint32 l_712 = l_mut_496 + l_710;
const uint32 l_713 = shared_memory_4[l_712];
const bool l_714 = l_703 < l_713;
const uint32 l_715 = l_mut_496 + l_710;
const uint32 l_716 = shared_memory_5[l_715];
const bool l_717 = l_703 >= l_716;
const bool l_718 = l_714 || l_717;
if (l_718) {
const uint32 l_719 = uint32(1) << l_710;
const uint32 l_720 = l_arr_562[uint32(1)];
const uint32 l_721 = l_720 ^ l_719;
l_arr_562[uint32(1)] = l_721;
}
}
}
const uint32 l_722 = l_arr_562[uint32(0)];
const uint32 l_723 = l_arr_439[uint32(0)];
const uint32 l_724 = l_722 & l_723;
const uint32 l_725 = uint32(__popc(l_724));
l_mut_16 = l_mut_16 + l_725;
const uint32 l_726 = l_arr_562[uint32(1)];
const uint32 l_727 = l_arr_439[uint32(1)];
const uint32 l_728 = l_726 & l_727;
const uint32 l_729 = uint32(__popc(l_728));
l_mut_16 = l_mut_16 + l_729;
const uint32 l_730 = l_arr_562[uint32(0)];
const uint32 l_731 = l_arr_439[uint32(0)];
const uint32 l_732 = l_730 & l_731;
l_mut_70 = l_732;
const uint32 l_733 = l_arr_438[uint32(0)];
while (true) {
const bool l_734 = l_mut_70 != uint32(0);
const bool l_735 = { __any_sync(-1, l_734)};
const bool l_736 = !l_735;
if (l_736) {
break;}
const bool l_737 = l_mut_70 != uint32(0);
if (l_737) {
const uint32 l_738 = uint32((l_mut_70 == 0 ? 32 : __ffs(l_mut_70) - 1));
const uint32 l_739 = l_mut_496 + l_738;
const uint32 l_740 = l_mut_70 - uint32(1);
l_mut_70 = l_mut_70 & l_740;
const uint32 l_741 = l_arr_440[uint32(0)];
const uint32 l_742 = l_arr_442[uint32(0)];
const uint32 l_743 = l_arr_441[uint32(0)];
const uint32 l_744 = l_arr_443[uint32(0)];
const uint32 l_745 = shared_memory_7[l_739];
const uint32 l_746 = l_arr_436[uint32(0)];
const uint32 l_747 = l_arr_437[uint32(0)];
const uint32 l_748 = shared_memory_8[l_739];
const uint32 l_749 = shared_memory_9[l_739];
const uint32 l_750 = l_743 * l_745;
const uint32 l_751 = l_741 + l_750;
const uint32 l_752 = l_744 * l_745;
const uint32 l_753 = l_742 + l_752;
const uint32 l_754 = __umulhi(l_751, uint32(60));
const uint32 l_755 = l_751 * uint32(60);
const uint32 l_756 = __umulhi(l_755, uint32(60));
const uint32 l_757 = __umulhi(l_753, uint32(60));
const uint32 l_758 = l_753 * uint32(60);
const uint32 l_759 = __umulhi(l_758, uint32(60));
const uint32 l_760 = l_747 | l_749;
const uint64 l_761 = uint64(l_760);
const uint64 l_762 = l_761 << uint64(32);
const uint32 l_763 = l_746 | l_748;
const uint64 l_764 = uint64(l_763);
const uint64 l_765 = l_762 | l_764;
const uint64 l_766 = uint64(l_756);
const uint64 l_767 = l_765 << l_766;
const uint64 l_768 = l_767 >> uint64(32);
const uint32 l_769 = uint32(l_768);
const uint64 l_770 = uint64(l_759);
const uint64 l_771 = l_765 << l_770;
const uint64 l_772 = l_771 >> uint64(32);
const uint32 l_773 = uint32(l_772);
const uint32 l_774 = l_769 | l_773;
const uint64 l_775 = uint64(l_754);
const uint64 l_776 = l_765 << l_775;
const uint64 l_777 = l_776 >> uint64(32);
const uint32 l_778 = uint32(l_777);
const uint32 l_779 = l_774 | l_778;
const uint64 l_780 = uint64(l_757);
const uint64 l_781 = l_765 << l_780;
const uint64 l_782 = l_781 >> uint64(32);
const uint32 l_783 = uint32(l_782);
const uint32 l_784 = l_779 | l_783;
l_mut_785 = bool(true);
const bool l_786 = l_756 == l_759;
const bool l_787 = l_754 == l_757;
const bool l_788 = l_786 || l_787;
const bool l_789 = l_756 == l_754;
const bool l_790 = l_788 || l_789;
const bool l_791 = l_756 == l_757;
const bool l_792 = l_790 || l_791;
const bool l_793 = l_759 == l_754;
const bool l_794 = l_792 || l_793;
const bool l_795 = l_759 == l_757;
const bool l_796 = l_794 || l_795;
const int32 l_797 = int32(l_784);
const bool l_798 = l_797 < int32(0);
const bool l_799 = l_796 || l_798;
if (l_799) {
l_mut_785 = bool(false);
}
if (l_mut_785) {
uint32* l_800 = &shared_memory_14[uint32(0)];
const uint32 l_801 = atomicAdd(l_800, uint32(1));
const bool l_802 = l_801 < uint32(1024);
if (l_802) {
const uint32 l_803 = shared_memory_6[l_739];
shared_memory_12[l_801] = l_803;
shared_memory_13[l_801] = l_733;
} else {
uint32* l_804 = &buffer_10[uint32(0)];
const uint32 l_805 = atomicAdd(l_804, uint32(1));
const bool l_806 = l_805 < info.scalars_uint32[2];
if (l_806) {
const uint32 l_807 = uint32(2) * l_805;
const uint32 l_808 = shared_memory_6[l_739];
buffer_9[l_807] = l_808;
const uint32 l_809 = uint32(2) * l_805;
const uint32 l_810 = l_809 + uint32(1);
buffer_9[l_810] = l_733;
}
}
}
}
__syncwarp();

}
const uint32 l_811 = l_arr_562[uint32(1)];
const uint32 l_812 = l_arr_439[uint32(1)];
const uint32 l_813 = l_811 & l_812;
l_mut_70 = l_813;
const uint32 l_814 = l_arr_438[uint32(1)];
while (true) {
const bool l_815 = l_mut_70 != uint32(0);
const bool l_816 = { __any_sync(-1, l_815)};
const bool l_817 = !l_816;
if (l_817) {
break;}
const bool l_818 = l_mut_70 != uint32(0);
if (l_818) {
const uint32 l_819 = uint32((l_mut_70 == 0 ? 32 : __ffs(l_mut_70) - 1));
const uint32 l_820 = l_mut_496 + l_819;
const uint32 l_821 = l_mut_70 - uint32(1);
l_mut_70 = l_mut_70 & l_821;
const uint32 l_822 = l_arr_440[uint32(1)];
const uint32 l_823 = l_arr_442[uint32(1)];
const uint32 l_824 = l_arr_441[uint32(1)];
const uint32 l_825 = l_arr_443[uint32(1)];
const uint32 l_826 = shared_memory_7[l_820];
const uint32 l_827 = l_arr_436[uint32(1)];
const uint32 l_828 = l_arr_437[uint32(1)];
const uint32 l_829 = shared_memory_8[l_820];
const uint32 l_830 = shared_memory_9[l_820];
const uint32 l_831 = l_824 * l_826;
const uint32 l_832 = l_822 + l_831;
const uint32 l_833 = l_825 * l_826;
const uint32 l_834 = l_823 + l_833;
const uint32 l_835 = __umulhi(l_832, uint32(60));
const uint32 l_836 = l_832 * uint32(60);
const uint32 l_837 = __umulhi(l_836, uint32(60));
const uint32 l_838 = __umulhi(l_834, uint32(60));
const uint32 l_839 = l_834 * uint32(60);
const uint32 l_840 = __umulhi(l_839, uint32(60));
const uint32 l_841 = l_828 | l_830;
const uint64 l_842 = uint64(l_841);
const uint64 l_843 = l_842 << uint64(32);
const uint32 l_844 = l_827 | l_829;
const uint64 l_845 = uint64(l_844);
const uint64 l_846 = l_843 | l_845;
const uint64 l_847 = uint64(l_837);
const uint64 l_848 = l_846 << l_847;
const uint64 l_849 = l_848 >> uint64(32);
const uint32 l_850 = uint32(l_849);
const uint64 l_851 = uint64(l_840);
const uint64 l_852 = l_846 << l_851;
const uint64 l_853 = l_852 >> uint64(32);
const uint32 l_854 = uint32(l_853);
const uint32 l_855 = l_850 | l_854;
const uint64 l_856 = uint64(l_835);
const uint64 l_857 = l_846 << l_856;
const uint64 l_858 = l_857 >> uint64(32);
const uint32 l_859 = uint32(l_858);
const uint32 l_860 = l_855 | l_859;
const uint64 l_861 = uint64(l_838);
const uint64 l_862 = l_846 << l_861;
const uint64 l_863 = l_862 >> uint64(32);
const uint32 l_864 = uint32(l_863);
const uint32 l_865 = l_860 | l_864;
l_mut_785 = bool(true);
const bool l_866 = l_837 == l_840;
const bool l_867 = l_835 == l_838;
const bool l_868 = l_866 || l_867;
const bool l_869 = l_837 == l_835;
const bool l_870 = l_868 || l_869;
const bool l_871 = l_837 == l_838;
const bool l_872 = l_870 || l_871;
const bool l_873 = l_840 == l_835;
const bool l_874 = l_872 || l_873;
const bool l_875 = l_840 == l_838;
const bool l_876 = l_874 || l_875;
const int32 l_877 = int32(l_865);
const bool l_878 = l_877 < int32(0);
const bool l_879 = l_876 || l_878;
if (l_879) {
l_mut_785 = bool(false);
}
if (l_mut_785) {
uint32* l_880 = &shared_memory_14[uint32(0)];
const uint32 l_881 = atomicAdd(l_880, uint32(1));
const bool l_882 = l_881 < uint32(1024);
if (l_882) {
const uint32 l_883 = shared_memory_6[l_820];
shared_memory_12[l_881] = l_883;
shared_memory_13[l_881] = l_814;
} else {
uint32* l_884 = &buffer_10[uint32(0)];
const uint32 l_885 = atomicAdd(l_884, uint32(1));
const bool l_886 = l_885 < info.scalars_uint32[2];
if (l_886) {
const uint32 l_887 = uint32(2) * l_885;
const uint32 l_888 = shared_memory_6[l_820];
buffer_9[l_887] = l_888;
const uint32 l_889 = uint32(2) * l_885;
const uint32 l_890 = l_889 + uint32(1);
buffer_9[l_890] = l_814;
}
}
}
}
__syncwarp();

}
__syncthreads();

uint32* l_891 = &shared_memory_14[uint32(0)];
const uint32 l_892 = atomicAdd(l_891, uint32(0));
__syncthreads();

const bool l_893 = l_892 >= uint32(512);
if (l_893) {
l_mut_70 = l_892;
const bool l_894 = l_mut_70 > uint32(1024);
if (l_894) {
l_mut_70 = uint32(1024);
}
const bool l_895 = threadIdx.x == uint32(0);
if (l_895) {
uint32* l_896 = &buffer_10[uint32(0)];
const uint32 l_897 = atomicAdd(l_896, l_mut_70);
shared_memory_15[uint32(0)] = l_897;
}
__syncthreads();

const uint32 l_898 = shared_memory_15[uint32(0)];
l_mut_67 = threadIdx.x;
while (true) {
const bool l_899 = l_mut_67 < l_mut_70;
const bool l_900 = !l_899;
if (l_900) {
break;}
const uint32 l_901 = l_898 + l_mut_67;
const bool l_902 = l_901 < info.scalars_uint32[2];
if (l_902) {
const uint32 l_903 = uint32(2) * l_901;
const uint32 l_904 = shared_memory_12[l_mut_67];
buffer_9[l_903] = l_904;
const uint32 l_905 = uint32(2) * l_901;
const uint32 l_906 = l_905 + uint32(1);
const uint32 l_907 = shared_memory_13[l_mut_67];
buffer_9[l_906] = l_907;
}
l_mut_67 = l_mut_67 + blockDim.x;
}
__syncthreads();

const bool l_908 = threadIdx.x == uint32(0);
if (l_908) {
uint32* l_909 = &shared_memory_14[uint32(0)];
uint32 _tmp_2 = atomicExch(l_909, uint32(0));
}
__syncthreads();

}
l_mut_496 = l_mut_496 + uint32(32);
}
l_mut_71 = l_mut_71 + uint32(512);
}
const bool l_910 = threadIdx.x < uint32(8);
if (l_910) {
uint32* l_911 = &shared_memory_10[threadIdx.x];
uint32 _tmp_3 = atomicExch(l_911, uint32(0));
}
l_mut_55 = l_mut_55 + uint32(256);
__syncthreads();

}
l_mut_21 = l_mut_21 + gridDim.x;
}
__syncthreads();

uint32* l_912 = &shared_memory_14[uint32(0)];
const uint32 l_913 = atomicAdd(l_912, uint32(0));
const bool l_914 = l_913 > uint32(0);
if (l_914) {
l_mut_496 = l_913;
const bool l_915 = l_mut_496 > uint32(1024);
if (l_915) {
l_mut_496 = uint32(1024);
}
const bool l_916 = threadIdx.x == uint32(0);
if (l_916) {
uint32* l_917 = &buffer_10[uint32(0)];
const uint32 l_918 = atomicAdd(l_917, l_mut_496);
shared_memory_15[uint32(0)] = l_918;
}
__syncthreads();

const uint32 l_919 = shared_memory_15[uint32(0)];
l_mut_477 = threadIdx.x;
while (true) {
const bool l_920 = l_mut_477 < l_mut_496;
const bool l_921 = !l_920;
if (l_921) {
break;}
const uint32 l_922 = l_919 + l_mut_477;
const bool l_923 = l_922 < info.scalars_uint32[2];
if (l_923) {
const uint32 l_924 = uint32(2) * l_922;
const uint32 l_925 = shared_memory_12[l_mut_477];
buffer_9[l_924] = l_925;
const uint32 l_926 = uint32(2) * l_922;
const uint32 l_927 = l_926 + uint32(1);
const uint32 l_928 = shared_memory_13[l_mut_477];
buffer_9[l_927] = l_928;
}
l_mut_477 = l_mut_477 + blockDim.x;
}
__syncthreads();

const bool l_929 = threadIdx.x == uint32(0);
if (l_929) {
uint32* l_930 = &shared_memory_14[uint32(0)];
uint32 _tmp_4 = atomicExch(l_930, uint32(0));
}
}
auto plane_l_931 = [&]() -> uint32 {
    uint32 acc = l_mut_16;
    for (uint offset = 1; offset < warpSizeChecked; offset *=2 ) {
acc += __shfl_xor_sync(-1, acc, offset);
    };
    return acc;
};
const uint32 l_931 = plane_l_931();
const bool l_932 = uint32(idxGlobal) % warpSize == uint32(0);
if (l_932) {
uint32* l_933 = &buffer_11[uint32(0)];
const uint32 l_934 = atomicAdd(l_933, l_931);
}
__syncthreads();

const bool l_935 = threadIdx.x == uint32(0);
if (l_935) {
uint32* l_936 = &buffer_12[uint32(4)];
const uint32 l_937 = atomicAdd(l_936, uint32(1));
}

}
