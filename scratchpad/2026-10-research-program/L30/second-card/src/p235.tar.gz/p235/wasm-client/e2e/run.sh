#!/bin/bash
# Run the browser E2E in the playwright container (no host browser needed).
# SwiftShader supplies a software WebGPU adapter, so the GPU path is tested
# end to end without GPU hardware. Usage: ./run.sh [e2e.mjs options], for
# example --skip-gpu or --parity-only (see the top of e2e.mjs).
set -euo pipefail
cd "$(dirname "$0")"
REPO_ROOT="$(cd ../.. && pwd)"
# The page loads d3/Plot from its local vendor copy (deploys run `just
# vendor-fetch`); fetch it here so the harness serves the same files.
bash "$REPO_ROOT/scripts/vendor-fetch.sh"
IMG=mcr.microsoft.com/playwright:v1.62.0-noble
docker run --rm -v "$REPO_ROOT":/repo -w /repo/wasm-client/e2e \
    --ipc=host "$IMG" bash -c "
        npm i --no-save --no-audit --no-fund playwright@1.62.0 >/dev/null 2>&1 &&
        node e2e.mjs $*"
